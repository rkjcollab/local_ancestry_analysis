As per the following ShapeIt page:
https://mathgen.stats.ox.ac.uk/genetics_software/shapeit/shapeit.html#gmap
The hapmap genetic map file was downloaded from: 
http://www.shapeit.fr/files/genetic_map_b37.tar.gz
on 29 April 2016
